package com.example.goout.model

data class Kid (var _id:String?= null, var Email: String?= null,
                var Myparent: String?= null, var Name: String?= null,
                var Password: String?= null, var Tasks: List<Any>?= null)