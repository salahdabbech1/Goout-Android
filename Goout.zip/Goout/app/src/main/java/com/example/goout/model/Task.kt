package com.example.goout.model

data class Task(var Name: String?= null,var Description: String?= null,var Status : String? = null, var kid: Long? = null)
